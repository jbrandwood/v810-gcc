#include <stdlib.h>

void
_malloc_stats_r (struct _reent *ptr)
{
  malloc_stats ();
}
